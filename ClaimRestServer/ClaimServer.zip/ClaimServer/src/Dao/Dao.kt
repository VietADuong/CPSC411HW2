package csuf.cpsc411.Dao

open class Dao {
    lateinit var sqlStmt : String
}