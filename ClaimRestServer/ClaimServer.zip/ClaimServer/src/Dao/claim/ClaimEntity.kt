package csuf.cpsc411.Dao.claim

data class ClaimEntity (var title:String?, var date:String?)