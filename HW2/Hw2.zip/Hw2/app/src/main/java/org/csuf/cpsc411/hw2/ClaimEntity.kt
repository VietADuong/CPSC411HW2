package org.csuf.cpsc411.hw2

data class ClaimEntity (var title:String?, var date:String?)
